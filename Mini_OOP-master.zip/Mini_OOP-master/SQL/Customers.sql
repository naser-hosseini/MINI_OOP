CREATE TABLE Customers
( 
  id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
  address char(200),
  email char(50),
  phone char(13)
);