CREATE TABLE Products
( 
  id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
  product_id int,
  product_name char(20),
  type_id INT,
  type char(20)
);