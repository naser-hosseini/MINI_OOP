CREATE TABLE Material
( 
  id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
  description CHAR(20),
  unit char(5)
)